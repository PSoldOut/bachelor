# bachelor
Meine Bachelorarbeit zum Thema "Visualisierung kinematischer Kennwerte".
